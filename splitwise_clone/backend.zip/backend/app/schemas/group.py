from pydantic import BaseModel
from typing import List

class GroupCreate(BaseModel):
    name: str
    member_ids: List[int]

class GroupResponse(BaseModel):
    id: int
    name: str
    members: List[int]  # You can replace with a nested UserOut if needed

    class Config:
        from_attributes = True
