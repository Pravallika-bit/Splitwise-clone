from fastapi import APIRouter

router = APIRouter()

@router.get("/group")
def get_group():
    return {"message": "Group endpoint working"}
