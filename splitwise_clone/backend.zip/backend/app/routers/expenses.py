# app/routers/expenses.py
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import expense as models
from app.models import group as group_models
from app.schemas import expense as schemas

router = APIRouter()

@router.post("/groups/{group_id}/expenses", response_model=schemas.ExpenseResponse)
def create_expense(group_id: int, request: schemas.ExpenseCreate, db: Session = Depends(get_db)):
    group = db.query(group_models.Group).filter(group_models.Group.id == group_id).first()
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")

    new_expense = models.Expense(
        description=request.description,
        amount=request.amount,
        paid_by=request.paid_by,
        group_id=group_id,
        split_type=request.split_type
    )
    db.add(new_expense)
    db.commit()
    db.refresh(new_expense)

    total_amount = request.amount
    if request.split_type == schemas.SplitTypeEnum.equal:
        split_amount = round(total_amount / len(request.splits), 2)
        for split in request.splits:
            db.add(models.ExpenseSplit(
                expense_id=new_expense.id,
                user_id=split.user_id,
                amount=split_amount
            ))
    elif request.split_type == schemas.SplitTypeEnum.percentage:
        total_percentage = sum(s.percentage for s in request.splits if s.percentage is not None)
        if round(total_percentage) != 100:
            raise HTTPException(status_code=400, detail="Total percentage must be 100")
        for split in request.splits:
            db.add(models.ExpenseSplit(
                expense_id=new_expense.id,
                user_id=split.user_id,
                percentage=split.percentage,
                amount=(total_amount * split.percentage / 100)
            ))
    else:
        raise HTTPException(status_code=400, detail="Invalid split type")

    db.commit()
    return new_expense
