from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.schemas.group import GroupCreate, GroupResponse
from app.models.group import Group
from app.models.group_user import GroupUser
from app.models.expense import Expense, ExpenseSplit

router = APIRouter()

@router.post("/groups/", response_model=GroupResponse)
def create_group(group: GroupCreate, db: Session = Depends(get_db)):
    new_group = Group(name=group.name)
    db.add(new_group)
    db.commit()
    db.refresh(new_group)

    for user_id in group.members:
        db.add(GroupUser(group_id=new_group.id, user_id=user_id))

    db.commit()
    return new_group


@router.get("/groups/{group_id}/balances")
def get_group_balances(group_id: int, db: Session = Depends(get_db)):
    group = db.query(Group).filter(Group.id == group_id).first()
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")

    expenses = db.query(Expense).filter(Expense.group_id == group_id).all()
    if not expenses:
        return {"message": "No expenses found in this group"}

    balances = {}

    for expense in expenses:
        splits = db.query(ExpenseSplit).filter(ExpenseSplit.expense_id == expense.id).all()

        for split in splits:
            balances.setdefault(split.user_id, 0)
            if split.user_id == expense.paid_by:
                balances[split.user_id] += expense.amount - split.amount
            else:
                balances[split.user_id] -= split.amount

    return {"group_id": group_id, "balances": balances}
